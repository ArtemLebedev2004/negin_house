<?php

namespace App\Http\Requests;

use App\Rules\RequiredCheckbox;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class FormSendRequest extends FormRequest
{
    
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'name' => [
                'required'
            ],
            'phone' => [
                'required'
            ],
            'checkbox' => [
                'required'
            ],
        ];
    }
}
