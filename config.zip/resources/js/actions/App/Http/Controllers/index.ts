import formSendController from './formSendController'
import AdminController from './AdminController'
const Controllers = {
    formSendController: Object.assign(formSendController, formSendController),
AdminController: Object.assign(AdminController, AdminController),
}

export default Controllers