import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\AdminController::login
 * @see app/Http/Controllers/AdminController.php:14
 * @route '/adminLogin'
 */
export const login = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

login.definition = {
    methods: ["post"],
    url: '/adminLogin',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\AdminController::login
 * @see app/Http/Controllers/AdminController.php:14
 * @route '/adminLogin'
 */
login.url = (options?: RouteQueryOptions) => {
    return login.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\AdminController::login
 * @see app/Http/Controllers/AdminController.php:14
 * @route '/adminLogin'
 */
login.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: login.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\AdminController::login
 * @see app/Http/Controllers/AdminController.php:14
 * @route '/adminLogin'
 */
    const loginForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: login.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\AdminController::login
 * @see app/Http/Controllers/AdminController.php:14
 * @route '/adminLogin'
 */
        loginForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: login.url(options),
            method: 'post',
        })
    
    login.form = loginForm
const AdminController = { login }

export default AdminController