import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
const Controller980bb49ee7ae63891f1d891d2fbcf1c9 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})

Controller980bb49ee7ae63891f1d891d2fbcf1c9.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
Controller980bb49ee7ae63891f1d891d2fbcf1c9.url = (options?: RouteQueryOptions) => {
    return Controller980bb49ee7ae63891f1d891d2fbcf1c9.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
Controller980bb49ee7ae63891f1d891d2fbcf1c9.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
Controller980bb49ee7ae63891f1d891d2fbcf1c9.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
    const Controller980bb49ee7ae63891f1d891d2fbcf1c9Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
        Controller980bb49ee7ae63891f1d891d2fbcf1c9Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/'
 */
        Controller980bb49ee7ae63891f1d891d2fbcf1c9Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller980bb49ee7ae63891f1d891d2fbcf1c9.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller980bb49ee7ae63891f1d891d2fbcf1c9.form = Controller980bb49ee7ae63891f1d891d2fbcf1c9Form
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/privacy_policy'
 */
const Controllerccb1fda95cbf13e579c0da9d2e4ba8c4 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllerccb1fda95cbf13e579c0da9d2e4ba8c4.url(options),
    method: 'get',
})

Controllerccb1fda95cbf13e579c0da9d2e4ba8c4.definition = {
    methods: ["get","head"],
    url: '/privacy_policy',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/privacy_policy'
 */
Controllerccb1fda95cbf13e579c0da9d2e4ba8c4.url = (options?: RouteQueryOptions) => {
    return Controllerccb1fda95cbf13e579c0da9d2e4ba8c4.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/privacy_policy'
 */
Controllerccb1fda95cbf13e579c0da9d2e4ba8c4.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllerccb1fda95cbf13e579c0da9d2e4ba8c4.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/privacy_policy'
 */
Controllerccb1fda95cbf13e579c0da9d2e4ba8c4.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controllerccb1fda95cbf13e579c0da9d2e4ba8c4.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/privacy_policy'
 */
    const Controllerccb1fda95cbf13e579c0da9d2e4ba8c4Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controllerccb1fda95cbf13e579c0da9d2e4ba8c4.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/privacy_policy'
 */
        Controllerccb1fda95cbf13e579c0da9d2e4ba8c4Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllerccb1fda95cbf13e579c0da9d2e4ba8c4.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/privacy_policy'
 */
        Controllerccb1fda95cbf13e579c0da9d2e4ba8c4Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllerccb1fda95cbf13e579c0da9d2e4ba8c4.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controllerccb1fda95cbf13e579c0da9d2e4ba8c4.form = Controllerccb1fda95cbf13e579c0da9d2e4ba8c4Form
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin-panel'
 */
const Controllera3be2d7635069cb63506f0eb198d5646 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllera3be2d7635069cb63506f0eb198d5646.url(options),
    method: 'get',
})

Controllera3be2d7635069cb63506f0eb198d5646.definition = {
    methods: ["get","head"],
    url: '/admin-panel',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin-panel'
 */
Controllera3be2d7635069cb63506f0eb198d5646.url = (options?: RouteQueryOptions) => {
    return Controllera3be2d7635069cb63506f0eb198d5646.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin-panel'
 */
Controllera3be2d7635069cb63506f0eb198d5646.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controllera3be2d7635069cb63506f0eb198d5646.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin-panel'
 */
Controllera3be2d7635069cb63506f0eb198d5646.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controllera3be2d7635069cb63506f0eb198d5646.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin-panel'
 */
    const Controllera3be2d7635069cb63506f0eb198d5646Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controllera3be2d7635069cb63506f0eb198d5646.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin-panel'
 */
        Controllera3be2d7635069cb63506f0eb198d5646Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllera3be2d7635069cb63506f0eb198d5646.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin-panel'
 */
        Controllera3be2d7635069cb63506f0eb198d5646Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controllera3be2d7635069cb63506f0eb198d5646.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controllera3be2d7635069cb63506f0eb198d5646.form = Controllera3be2d7635069cb63506f0eb198d5646Form
    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin-login'
 */
const Controller65d3cf2b2d02875a2d5644c2ba52fe60 = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller65d3cf2b2d02875a2d5644c2ba52fe60.url(options),
    method: 'get',
})

Controller65d3cf2b2d02875a2d5644c2ba52fe60.definition = {
    methods: ["get","head"],
    url: '/admin-login',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin-login'
 */
Controller65d3cf2b2d02875a2d5644c2ba52fe60.url = (options?: RouteQueryOptions) => {
    return Controller65d3cf2b2d02875a2d5644c2ba52fe60.definition.url + queryParams(options)
}

/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin-login'
 */
Controller65d3cf2b2d02875a2d5644c2ba52fe60.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: Controller65d3cf2b2d02875a2d5644c2ba52fe60.url(options),
    method: 'get',
})
/**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin-login'
 */
Controller65d3cf2b2d02875a2d5644c2ba52fe60.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: Controller65d3cf2b2d02875a2d5644c2ba52fe60.url(options),
    method: 'head',
})

    /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin-login'
 */
    const Controller65d3cf2b2d02875a2d5644c2ba52fe60Form = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: Controller65d3cf2b2d02875a2d5644c2ba52fe60.url(options),
        method: 'get',
    })

            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin-login'
 */
        Controller65d3cf2b2d02875a2d5644c2ba52fe60Form.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller65d3cf2b2d02875a2d5644c2ba52fe60.url(options),
            method: 'get',
        })
            /**
* @see \Inertia\Controller::__invoke
 * @see vendor/inertiajs/inertia-laravel/src/Controller.php:13
 * @route '/admin-login'
 */
        Controller65d3cf2b2d02875a2d5644c2ba52fe60Form.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: Controller65d3cf2b2d02875a2d5644c2ba52fe60.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    Controller65d3cf2b2d02875a2d5644c2ba52fe60.form = Controller65d3cf2b2d02875a2d5644c2ba52fe60Form

/**
* Multiple routes resolve to \Inertia\Controller::Controller, so this export is a
* dictionary keyed by URI rather than a callable. Call a specific route with `Controller['<uri>'](...)`,
* or import the route by name from your generated `routes/` directory.
*/
const Controller = {
    '/': Controller980bb49ee7ae63891f1d891d2fbcf1c9,
    '/privacy_policy': Controllerccb1fda95cbf13e579c0da9d2e4ba8c4,
    '/admin-panel': Controllera3be2d7635069cb63506f0eb198d5646,
    '/admin-login': Controller65d3cf2b2d02875a2d5644c2ba52fe60,
}

export default Controller