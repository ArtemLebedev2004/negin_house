import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\formSendController::index
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/formSend',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\formSendController::index
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\formSendController::index
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\formSendController::index
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\formSendController::index
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\formSendController::index
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\formSendController::index
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\formSendController::create
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/formSend/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\formSendController::create
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\formSendController::create
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\formSendController::create
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\formSendController::create
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\formSendController::create
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\formSendController::create
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\formSendController::store
 * @see app/Http/Controllers/formSendController.php:12
 * @route '/formSend'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/formSend',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\formSendController::store
 * @see app/Http/Controllers/formSendController.php:12
 * @route '/formSend'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\formSendController::store
 * @see app/Http/Controllers/formSendController.php:12
 * @route '/formSend'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\formSendController::store
 * @see app/Http/Controllers/formSendController.php:12
 * @route '/formSend'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\formSendController::store
 * @see app/Http/Controllers/formSendController.php:12
 * @route '/formSend'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\formSendController::show
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
export const show = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/formSend/{formSend}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\formSendController::show
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
show.url = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { formSend: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    formSend: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        formSend: args.formSend,
                }

    return show.definition.url
            .replace('{formSend}', parsedArgs.formSend.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\formSendController::show
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
show.get = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\formSendController::show
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
show.head = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\formSendController::show
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
    const showForm = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\formSendController::show
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
        showForm.get = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\formSendController::show
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
        showForm.head = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\formSendController::edit
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}/edit'
 */
export const edit = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/formSend/{formSend}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\formSendController::edit
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}/edit'
 */
edit.url = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { formSend: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    formSend: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        formSend: args.formSend,
                }

    return edit.definition.url
            .replace('{formSend}', parsedArgs.formSend.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\formSendController::edit
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}/edit'
 */
edit.get = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\formSendController::edit
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}/edit'
 */
edit.head = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\formSendController::edit
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}/edit'
 */
    const editForm = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\formSendController::edit
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}/edit'
 */
        editForm.get = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\formSendController::edit
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}/edit'
 */
        editForm.head = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\formSendController::update
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
export const update = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/formSend/{formSend}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\formSendController::update
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
update.url = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { formSend: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    formSend: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        formSend: args.formSend,
                }

    return update.definition.url
            .replace('{formSend}', parsedArgs.formSend.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\formSendController::update
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
update.put = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\formSendController::update
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
update.patch = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\formSendController::update
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
    const updateForm = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\formSendController::update
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
        updateForm.put = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\formSendController::update
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
        updateForm.patch = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\formSendController::destroy
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
export const destroy = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/formSend/{formSend}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\formSendController::destroy
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
destroy.url = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { formSend: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    formSend: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        formSend: args.formSend,
                }

    return destroy.definition.url
            .replace('{formSend}', parsedArgs.formSend.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\formSendController::destroy
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
destroy.delete = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\formSendController::destroy
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
    const destroyForm = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\formSendController::destroy
 * @see app/Http/Controllers/formSendController.php:0
 * @route '/formSend/{formSend}'
 */
        destroyForm.delete = (args: { formSend: string | number } | [formSend: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const formSend = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default formSend